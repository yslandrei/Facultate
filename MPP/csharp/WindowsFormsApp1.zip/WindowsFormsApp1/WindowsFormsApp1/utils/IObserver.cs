namespace WindowsFormsApp1.utils;

public interface IObserver
{
    void Update();
}