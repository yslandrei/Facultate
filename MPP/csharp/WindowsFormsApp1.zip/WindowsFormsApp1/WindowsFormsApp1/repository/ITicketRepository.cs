using WindowsFormsApp1.domain;

namespace WindowsFormsApp1.repository;

public interface ITicketRepository : IRepository<long, Ticket>
{
    
}