using csharp.domain;

namespace csharp.repository;

public interface IUserRepository : IRepository<long, User>
{
    
}