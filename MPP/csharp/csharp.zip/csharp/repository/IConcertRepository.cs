using csharp.domain;

namespace csharp.repository;

public interface IConcertRepository : IRepository<long, Concert>
{
    
}