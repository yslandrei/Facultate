package org.example.repository;

import org.example.domain.Ticket;

public interface TicketRepository extends Repository<Long, Ticket>{
}
