package org.example.utils.observer;


public interface Observer {
    void update();
}